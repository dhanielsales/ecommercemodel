# coding=utf-8

default_app_config = 'core.apps.CoreConfig'
