from django.apps import AppConfig


class CheckoutConfig(AppConfig):
    name = 'checkout'
